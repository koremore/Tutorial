Musical Dice Game — July 2026 Release
=====================================

Latest game source (July 10, 2026) with the D4 ledger-line bug fix.

Quick start
-----------
  npm install
  npm run dev
  Open http://localhost:5173

Production build
----------------
  npm run build
  npm start

Contents
--------
  client/          React frontend (game UI, music notation, all 5 levels)
  server/          Express static server for production
  package.json     Dependencies and scripts
  vite.config.ts   Vite build configuration
  tsconfig*.json   TypeScript configuration
